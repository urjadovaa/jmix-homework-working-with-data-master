package com.sample.carmarket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HomeworkCarmarketApplicationTests {

	@Test
	void contextLoads() {
	}

}
